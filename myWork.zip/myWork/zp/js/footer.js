$(function(){
    $("#foot").load("../zp-dl-footer.html")
});