var oli=document.getElementById("li1");
var odiv=document.getElementById("div1");

oli.onmouseover = function(){
    odiv.style.display="block";
};

oli.onmouseout = function(){
    odiv.style.display="none";
};

